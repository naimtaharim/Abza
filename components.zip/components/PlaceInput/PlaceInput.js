import React, { Component } from "react";
import { View, TextInput, Button, StyleSheet, Text, TouchableOpacity } from "react-native";
import DropdownMenu from 'react-native-dropdown-menu';
import DatePicker from 'react-native-datepicker';






class PlaceInput extends Component {
  constructor(props) {
    super(props)
    this.state = { date: "2016-05-15" }
    
    }
   
  
  

  state = {
    placeName: ""
  };

  componentDidMount() {

  }

  placeNameChangedHandler = val => {
    this.setState({
      placeName: val
    });
  };

  placeSubmitHandler = () => {
    if (this.state.placeName.trim() === "") {
      return;
    }

    this.props.onPlaceAdded(this.state.placeName);
  };



  render() {

    var data = [["juz 1", "Juz2", "Juz3", "juz4", "juz 5", "Juz6", "Juz7", "juz8", "juz 9", "Juz10", "Juz11", "juz12", "juz 13", "Juz14", "Juz15",
      "juz16",],
    ["1 week", "2 week", "3 week", "4 week"]];



    return (
      <View>

        <View style={styles.inputContainer}>

          <TextInput
            placeholder="create group name"
            value={this.state.placeName}
            onChangeText={this.placeNameChangedHandler}
            style={styles.placeInput}
          />
          <Button
            title="Add"
            style={styles.placeButton}
            onPress={this.placeSubmitHandler}
          />
        </View>



        <View style={{ flex: 1 }}>
          <View style={{ height: 64 }} />
          <DropdownMenu
            style={{ flex: 1 }}
            bgColor={'#00CBCB'}
            tintColor={'#474747'}
            activityTintColor={'green'}

            handler={(selection, row) => this.setState({ text: data[selection][row] })}
            data={data}
          >
          
          </DropdownMenu>
          </View>


            <View style={{ flex: 1 }}>
              <DatePicker
                style={{ width: 200 }}
                date={this.state.date}
                mode="date"
                placeholder="select date"
                format="YYYY-MM-DD"
                minDate="2016-05-01"
                maxDate="2016-06-01"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                customStyles={{
                  dateIcon: {
                    position: 'absolute',
                    left: 0,
                    top: 4,
                    marginLeft: 0
                  },
                  dateInput: {
                    marginLeft: 36
                  }
                  
                }}
                onDateChange={(date) => { this.setState({ date: date }) }}
              />
              )
            }
          }

     </View>
     
       </View>
      
    );
  }
}

const styles = StyleSheet.create({
  inputContainer: {
    // flex: 1,
    width: "100%",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
  },
  placeInput: {
    width: "70%",
    alignItems: "center"
  },
  placeButton: {
    width: "30%"
  }
});

export default PlaceInput;

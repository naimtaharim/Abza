import React, { Component } from 'react';
import { View, Text, WebView } from 'react-native';

class QuranScreen extends Component {
    constructor(props) {
        super(props);
        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent);
    }

    onNavigatorEvent = event => {
        if (event.type === "NavBarButtonPress") {
            if (event.id === "sideDrawerToggle") {
                this.props.navigator.toggleDrawer({
                    side: "left"
                });
            }
        }
    }

    render() {
        return (
            <WebView
                source={{ uri: 'https://quran.com' }}
                style={{ marginTop: 20 }}
            />
        );
    }
}

export default QuranScreen;
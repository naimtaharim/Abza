import React, { Component } from 'react';
import { Text,TextInput, TouchableOpacity, View } from 'react-native';
import DateTimePicker from 'react-native-modal-datetime-picker';

 class ProfileScreen extends Component {
  state = {
    isDateTimePickerVisible: false,
  };

  _showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

  _hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });

  _handleDatePicked = (date) => {
    console.log('A date has been picked: ', date);
    this._hideDateTimePicker();
  };


  constructor(props) {
    super(props);
    this.state = {
      text: ''
    };
  }
  
  render() {
    return (
    


  

      

          <View style={{flex: 1}}>
            <TouchableOpacity onPress={this._showDateTimePicker}>
        <TextInput
         placeholder="create group name"
         />

          <Text>Show DatePicker</Text>
        </TouchableOpacity>
        <DateTimePicker
          isVisible={this.state.isDateTimePickerVisible}
          onConfirm={this._handleDatePicked}
          onCancel={this._hideDateTimePicker}
        />

          </View>

       
      
    );
  }
  
}

    export default ProfileScreen


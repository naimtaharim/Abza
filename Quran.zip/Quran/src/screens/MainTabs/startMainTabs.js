import { Navigation } from 'react-native-navigation';
import {Platform } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

const startTabs = () => {
    Promise.all([
        Icon.getImageSource(Platform.OS==='android' ? "md-people" : "ios-people", 30),
        Icon.getImageSource(Platform.OS==='android' ? "md-add-circle" : "ios-add-circle", 30),
        Icon.getImageSource(Platform.Os==='android' ? "md-person" : "ios-person",30),
        Icon.getImageSource(Platform.OS==='android' ? "md-heart" : "ios-heart",30),
        Icon.getImageSource(Platform.Os==='android' ? "md-menu" : "ios-menu",30),
        Icon.getImageSource(Platform.OS==='android' ? "md-book" : "ios-book",30)

        
    ]).then(sources => {
    
        Navigation.startTabBasedApp({
            tabs: [
                {
                    screen: "awesome-places.FindPlaceScreen",
                    label: " Group",
                    title: " Group",
                    icon: sources[0],
                    navigatorButtons:{
                        leftButtons:[
                            {
                                icon: sources[4],
                                title:"Menu",
                                id:"sideDrawerToggle"
                            }
                        ]
                    }
                    
                    
                },
                {
                    screen: "awesome-places.SharePlaceScreen",
                    label: "Create Group",
                    title: "Create Group",
                    icon: sources[1],
                    navigatorButtons:{
                        leftButtons:[
                            {
                                icon: sources[4],
                                title:"Menu",
                                id:"sideDrawerToggle"
                            }
                        ]
                    }

                    
                },

                {
                screen: "awesome-places.QuranScreen", 
                label: "Quran",
                title: "Quran",
                icon: sources[5],
                navigatorButtons:{
                    leftButtons:[
                        {
                            icon: sources[4],
                            title:"Menu",
                            id:"sideDrawerToggle"
                        }
                    ]
                }
            },

                {
                    screen: "awesome-places.ProfileScreen",
                    label: "Profile",
                    title: "Profile",  
                    icon: sources[2],
                    navigatorButtons:{
                        leftButtons:[
                            {
                                icon: sources[4],
                                title:"Menu",
                                id:"sideDrawerToggle"
                            }
                        ]
                    }
                },
                {
                    screen: "awesome-places.DonateScreen",
                    label: "Donate",
                    title: "Donate",
                    icon: sources[3],
                    navigatorButtons:{
                        leftButtons:[
                            {
                                icon: sources[4],
                                title:"Menu",
                                id:"sideDrawerToggle"
                            }
                        ]
                    }
                }
            
        
            ],
            drawer:{
                left:{
                    screen:"awesome-places.SideDrawer"
                }
            }

        });
    
    });
}
export default startTabs;